package com.ssafy.realty;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RealtyApplicationTests {

    @Test
    void contextLoads() {
    }

}
