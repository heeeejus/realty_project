package com.ssafy.realty.realty.application.port.in.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ViewIncreaseDto {
    Long customId;
}
