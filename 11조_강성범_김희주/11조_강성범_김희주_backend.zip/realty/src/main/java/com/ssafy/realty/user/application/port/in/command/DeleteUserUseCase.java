package com.ssafy.realty.user.application.port.in.command;

public interface DeleteUserUseCase {

    void delete(Long id);
}
