package com.ssafy.realty.custom_deal.application.port.in.command;

import com.ssafy.realty.custom_deal.application.port.in.dto.StarCustomDto;

public interface StarCustomIncreaseUseCase {

    void starIncrease(StarCustomDto starCustomDto);
}
