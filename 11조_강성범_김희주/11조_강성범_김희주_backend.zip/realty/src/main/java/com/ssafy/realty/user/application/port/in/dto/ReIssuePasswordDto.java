package com.ssafy.realty.user.application.port.in.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ReIssuePasswordDto {
    String username;
}
