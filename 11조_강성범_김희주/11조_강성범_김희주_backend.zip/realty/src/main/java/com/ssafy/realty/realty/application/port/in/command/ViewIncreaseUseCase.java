package com.ssafy.realty.realty.application.port.in.command;

import com.ssafy.realty.realty.application.port.in.dto.ViewIncreaseDto;

public interface ViewIncreaseUseCase {

    void viewIncrease(ViewIncreaseDto viewIncreaseDto);
}
