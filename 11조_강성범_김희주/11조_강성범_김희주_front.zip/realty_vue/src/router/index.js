import { createRouter, createWebHistory } from "vue-router";
import HomeView from "../views/HomeView.vue";
import UserView from "../views/UserView.vue";
import CustomCatalogView from "../views//CustomCatalogView.vue";
import RealtyInfoView from "../views/RealtyInfoView.vue";
import CustomCatalog from "@/components/custom/CustomCatalog.vue";
import CustomDetail from "@/components/custom/CustomDetail.vue";
import LoginForm from "@/components/User/LoginForm.vue";
import UserRegistForm from "@/components/User/UserRegistForm.vue";
import UpdateForm from "@/components/User/UpdateForm.vue"
import ReIssuePassword from "@/components/User/ReIssuePassword.vue"

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: "/",
      name: "home",
      component: HomeView,
    },
    {
      path: "/user",
      name: "user",
      component: UserView,
      children: [
        //login
        {
          path: "/login",
          name: "login",
          component: LoginForm,
        },
        //user regist
        {
          path: "/signup",
          name: "signup",
          component: UserRegistForm,
        },
        {
          path: "/reissue-password",
          name: "reissue-password",
          component: ReIssuePassword,
        },
        //user update
        {
          path: "/update",
          name: "update",
          component: UpdateForm,
        },
      ],
    },
    {
      path: "/realtyInfo",
      name: "realtyInfo",
      component: RealtyInfoView,
    },
    {
      path: "/custom",
      name: "custom",
      component: CustomCatalogView,
      redirect: {name: "catalog"},
      children:[
        {
          path: "custom",
          name: "catalog",
          component: CustomCatalog,
        },
        {
          path: "detail/:customid",
          name: "custom-detail",
          component: CustomDetail,
        }
      ]
    }
  ],
});

export default router;
