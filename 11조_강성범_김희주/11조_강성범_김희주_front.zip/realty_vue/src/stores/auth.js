import { defineStore } from "pinia";
import { ref } from "vue";
import { localAxios } from "../util/http-commons";
import { jwtDecode } from "jwt-decode";

const local = localAxios();

//서버에 로그인 정보를 넘기고 token을 받아오기 위한 js
export const userAuthStore = defineStore(
  "auth",
  () => {
    //login user 정보 변수
    const user = ref({
      username: "",
      nickname: "",
      password: "",
    });
    const token = ref(""); //jwt 토큰 정보 담는 변수

    const login = async (loginForm) => {
      const { headers } = await local.post(`/login`, loginForm);
      //console.log("로그인 요청 후 응답 데이터: ", headers.accesstoken);

      token.value = headers.accesstoken; //토큰 정보 저장
      //console.log(token.value);

      const decoded = jwtDecode(token.value); //토큰에서 유저정보 추출하여 유저정보 저장
      //console.log("디코딩된 토큰 정보 : ", decoded);
      user.value.username = decoded.username;
      user.value.nickname = decoded.nickname;

      localStorage.setItem("user", JSON.stringify(user.value));
      localStorage.setItem("token", token.value);
      // console.log("localStorage user:", localStorage.getItem("user"));
    };

    const clearUser = () => {
      user.value.username = "";
      user.value.nickname = "";
      token.value = "";
    };

    const logout = () => {
      clearUser();
      localStorage.setItem("token", "");
      localStorage.setItem("user", "");
    };

    const updateNickname = (nickname) => {
      user.value.nickname = nickname;
    }

  
    return { login, user, token, logout, clearUser, updateNickname };
  },
  { persist: { storage: localStorage } }
  //sessionStorage 사용하고 싶은 경우
  // {
  //   persist: {
  //     storage: sessionStorage,
  //   },
  // }
);
