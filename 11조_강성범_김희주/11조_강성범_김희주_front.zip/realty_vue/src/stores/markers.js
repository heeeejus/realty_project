import { ref } from "vue";
import { defineStore } from "pinia";

export const useMarkerStore = defineStore(
  "markerStore",
  () => {
    const markerInfo = ref({
      address: "",
      filter: {
        area: {
          lower: 0,
          upper: 0,
        },
        date: {
          lower: "",
          upper: "",
        },
        dealAmount: {
          lower: 0,
          upper: 0,
        },
        transportations: [
          {
            time: 5,
            type: "walk",
          },
        ],
      },
      lat: 0,
      lng: 0,
    });
    const markers = ref([
      {
        id: 1,
        time: 5,
        type: "walk",
        latlng: {},
        imgSrc: "img/pins/pin_blue.png",
        circle: {
          center: {},
          radius: 200,
          strokeWeight: 2,
          strokeColor: "#E57373",
          strokeOpacity: 1,
          strokeStyle: "solid",
          fillColor: "#EF9A9A",
          fillOpacity: 0.7,
        },
      },
      {
        id: 2,
        time: 10,
        type: "walk",
        latlng: {},
        imgSrc: "img/pins/pin_green.png",
        circle: {
          center: {},
          radius: 400,
          strokeWeight: 2,
          strokeColor: "#75B8FA",
          strokeOpacity: 1,
          strokeStyle: "solid",
          fillColor: "#CFE7FF",
          fillOpacity: 0.7,
        },
      },
      {
        id: 3,
        time: 15,
        type: "walk",
        latlng: {},
        imgSrc: "img/pins/pin_orange.png",
        circle: {
          center: {},
          radius: 600,
          strokeWeight: 2,
          strokeColor: "#BA68C8",
          strokeOpacity: 1,
          strokeStyle: "solid",
          fillColor: "#CE93D8",
          fillOpacity: 0.7,
        },
      },
      {
        id: 4,
        time: 5,
        type: "bicycle",
        latlng: {},
        imgSrc: "img/pins/pin_purple.png",
        circle: {
          center: {},
          radius: 300,
          strokeWeight: 2,
          strokeColor: "#80DEEA",
          strokeOpacity: 1,
          strokeStyle: "solid",
          fillColor: "#4DD0E1",
          fillOpacity: 0.7,
        },
      },
      {
        id: 5,
        time: 10,
        type: "bicycle",
        latlng: {},
        imgSrc: "img/pins/pin_red.png",
        circle: {
          center: {},
          radius: 625,
          strokeWeight: 2,
          strokeColor: "#81C784",
          strokeOpacity: 1,
          strokeStyle: "solid",
          fillColor: "#A5D6A7",
          fillOpacity: 0.7,
        },
      },
      {
        id: 6,
        time: 15,
        type: "bicycle",
        latlng: {},
        imgSrc: "img/pins/pin_yellow.png",
        circle: {
          center: {},
          radius: 888,
          strokeWeight: 2,
          strokeColor: "#FFD54F",
          strokeOpacity: 1,
          strokeStyle: "solid",
          fillColor: "#FFE082",
          fillOpacity: 0.7,
        },
      },
    ]);

    const position = [];

    const sessionMarkerUpdate = (markerInfo) => {
      sessionStorage.setItem("markerInfo", JSON.stringify(markerInfo));
    };

    const sessionPositionUpdate = (position) => {
      const tmp = `{ "data":${JSON.stringify(position)} }`;
      sessionStorage.setItem("position", tmp);
    };
    return {
      markers,
      sessionMarkerUpdate,
      markerInfo,
      position,
      sessionPositionUpdate,
    };
  },
  {
    persist: {
      storage: sessionStorage,
    },
  }
);
