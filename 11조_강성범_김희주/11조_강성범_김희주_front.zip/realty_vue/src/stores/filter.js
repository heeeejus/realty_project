import { ref } from "vue";
import { defineStore } from "pinia";

export const useFilterStore = defineStore(
  "filterStore",
  () => {
    const filter = ref({
      area: {
        lower: 0,
        upper: 0,
      },
      date: {
        lower: "",
        upper: "",
      },
      dealAmount: {
        lower: 0,
        upper: 0,
      },
      transportations: [
        {
          time: 0,
          type: "",
        },
      ],
    });

    const sessionFilterUpdate = (filter) => {
      sessionStorage.setItem("filter", JSON.stringify(filter));
    };
    return {
      filter,
      sessionFilterUpdate,
    };
  },
  {
    persist: {
      storage: sessionStorage,
    },
  }
);
