import { localAxios } from "../util/http-commons";

const local = localAxios();
const realty = "/realty";

// function markerList(markerInfo, success, fail) {
//   console.log("markerInfo list", markerInfo);
//   local.post(`${realty}/realty-info`, markerInfo).then(success).catch(fail);
// }
function markerList(markerInfo) {
  console.log("markerInfo list", markerInfo);
  return local.post(`${realty}/realty-info`, markerInfo);
}

function markerSave(markerInfo) {
  console.log("markerInfo save", markerInfo);
  return local.post(`${realty}/save`, markerInfo);
}

function aptDealList(aptCode) {
  console.log("aptCode : ", aptCode);
  return local.get(`${realty}/${aptCode}`);
}

function markerShareSave(markerInfo) {
  console.log("markerInfo ", markerInfo);
  return local.post(`${realty}/tmp/save`, markerInfo);
}

function markerShareList() {
  return local.get(`${realty}/tmp`);
}
export {
  markerList,
  aptDealList,
  markerSave,
  markerShareSave,
  markerShareList,
};
