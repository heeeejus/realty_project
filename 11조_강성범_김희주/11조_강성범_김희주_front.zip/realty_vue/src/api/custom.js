import { localAxios } from "@/util/http-commons";

const local = localAxios();

function customCatalogs(param, success, fail) {
  local.get(`/custom/search`, { params: param }).then(success).catch(fail);
}

function myCatalogRequest(param, success, fail) {
  local.get(`/custom/my-catalog`, { params: param }).then(success).catch(fail);
}


function myStarRequest(param, success, fail) {
  local.get(`/custom/star/own`, { params: param }).then(success).catch(fail);
}

function markerInfoRequest(data, success, fail) {
  local.get(`/realty/custom/${data}`, {withCredentials: true}).then(success).catch(fail);
}

function customLike(customId, success, fail){
  local.post(`/custom/star/${customId}`).then(success).catch(fail);
}

export {
    customCatalogs, myStarRequest, myCatalogRequest, markerInfoRequest, customLike
};
  