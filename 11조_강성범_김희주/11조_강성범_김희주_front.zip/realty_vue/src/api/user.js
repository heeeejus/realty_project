import { localAxios } from "../util/http-commons";

const local = localAxios();

function registUser(userInfo, success, fail) {
  console.log("user regist", userInfo);
  local.post(`/regist`, userInfo).then(success).catch(fail);
}

function updateUser(updateInfo, success, fail) {
  console.log("user update", updateInfo);
  local.patch(`/user/update`, updateInfo).then(success).catch(fail);
}

function removeUser(success, fail) {
  local.delete(`/user/delete`).then(success).catch(fail);
}

function reIssuePassword(usernameInfo, success, fail) {
  local.post(`/reissue-password`, usernameInfo).then(success).catch(fail);
}

export { registUser, updateUser, removeUser, reIssuePassword };
