import axios from "axios";
import { userAuthStore } from "@/stores/auth";
const { VITE_REALTY_API_URL } = import.meta.env;

//local vue api axios instance
function localAxios() {
  const instance = axios.create({
    baseURL: VITE_REALTY_API_URL,
  });

  instance.interceptors.request.use(
    (config) => {
      const authStore = userAuthStore();
      config.headers.accessToken = `${localStorage.token}`;
      console.log("요청 intercept", config);
      return config;
    },

    (error) => Promise.reject(error)
  );

  return instance;
}

export { localAxios };
