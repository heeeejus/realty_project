<script setup>
import VKakaoMap from "../components/common/VKakaoMap.vue";
import VListNav from "../components/common/VListNav.vue";
import VChipPanel from "../components/common/VChipPanel.vue";
import VSearchBar from "../components/common/VSearchBar.vue";
import VMarkerSaveBtn from "../components/common/VMarkerSaveBtn.vue";

import { ref, onBeforeMount, onMounted } from "vue";

import { useRouter } from "vue-router";
import { useMarkerStore } from "../stores/markers";
import { useFilterStore } from "../stores/filter";

const router = useRouter();
const markerStore = useMarkerStore();
const filterStore = useFilterStore();

const chipHeight = ref();
const chipWidth = ref();
const markerInfo = ref();
const position = ref([]);
const disable = ref(true);
const chipName = ["면적", "거래일", "거래가격", "도보/자전거"];

const cardShow = (cardShow) => {
  chipHeight.value = !cardShow;
  chipWidth.value = cardShow;
};
const markerInfoEvent = (marker) => {
  //마커에 대한 정보를 넘겨서 VListNav에서 리스트 보여주기
  console.log("marker ", marker);
  markerInfo.value = marker;
  markerInfo.value.filter = JSON.parse(sessionStorage.getItem("filter"));
  //sessionStorage.setItem("filter", JSON.stringify(markerInfo.value.filter));
  sessionStorage.setItem("markerInfo", JSON.stringify(markerInfo.value));
};

const infoListEvent = (infoList) => {
  //infoList의 latlng position에 저장
  sessionStorage.setItem("position", "");
  position.value = [];
  infoList.forEach((val) => {
    const tmp = {
      title: val.apartmentName,
      lat: val.lat,
      lng: val.lng,
      //latlng: new kakao.maps.LatLng(val.lat, val.lng),
    };
    //markerStore.sessionPositionUpdate(markerStore.position);
    position.value.push(tmp);
  });
  const obj = { data: position.value };
  sessionStorage.setItem("position", JSON.stringify(obj));
};

let isPageRefresh = false;
router.beforeEach((to, from, next) => {
  console.log(from.name, to.name);
  if (from.name === "custom-detail" && to.name === "realtyInfo") {
    // This is a page refresh
    //isPageRefresh = true;
    markerInfo.value = JSON.parse(sessionStorage.getItem("markerInfo"));
    markerInfoEvent(markerInfo.value);
    sessionStorage.setItem("filter", JSON.stringify(markerInfo.value.filter));
  }

  if (from.name === "home" && to.name === "realtyInfo") {
    // markerStore.markerInfo.filter.transportations = [{'type' : 'walk', 'time' : 5}];
    //filterStore.filter.transportations = [{ type: "walk", time: 5 }];
    //console.log(filterStore.filter);
    sessionStorage.setItem(
      "filter",
      JSON.stringify(markerStore.markerInfo.filter)
    );
    sessionStorage.setItem(
      "markerInfo",
      JSON.stringify(markerStore.markerInfo)
    );
    sessionStorage.setItem("position", "");
  }

  next();
});
onBeforeMount(() => {
  //const info = JSON.parse(sessionStorage.getItem("markerInfo"));
  sessionStorage.setItem(
    "markerInfo",
    JSON.stringify(markerStore.markerInfo.data[0])
  );
  const info = JSON.parse(sessionStorage.getItem("markerInfo"));
  console.log(JSON.stringify(markerStore.markerInfo));
  sessionStorage.setItem("filter", JSON.stringify(info.filter));
  if (isPageRefresh) {
    // Perform actions specific to a page refresh
    console.log("Page Refresh Detected");
    // For example, you can call your makerInfoRequest() here
  }
});

onMounted(() => {
  markerInfo.value = JSON.parse(sessionStorage.getItem("markerInfo"));
});
</script>

<template>
  <v-container fluid class="pd-0">
    <v-container fluid class="d-flex v-con">
      <VListNav
        class="list-nav"
        v-on:infoList="infoListEvent"
        :markerInfo="markerInfo"
      ></VListNav>
      <VKakaoMap
        class="map"
        v-on:markerInfo="markerInfoEvent"
        :markerInfo="markerInfo"
        :position="position"
      ></VKakaoMap>
      <div class="d-flex chip-panel">
        <VChipPanel
          :disable="false"
          :class="{
            'chip-panel-height': chipHeight,
            'chip-panel-width': chipWidth,
          }"
          v-on:card-show="cardShow"
          v-for="name in chipName"
          :key="chipName"
          :chip-name="name"
        ></VChipPanel>
      </div>
      <!-- <VSearchBar class="search-bar"></VSearchBar> -->
      <VMarkerSaveBtn
        v-if="markerInfo != null"
        class="marker-save-btn"
        :markerInfo="markerInfo"
      ></VMarkerSaveBtn>
    </v-container>
  </v-container>
</template>

<style scoped>
.v-container::v-deep {
  height: 100%;
}
.pd-0 {
  padding: 0;
}
.v-con {
  padding: 0;
  position: relative;
}
.map {
  z-index: auto;
}
.list-nav {
  position: absolute;
  top: 8%;
  left: 1%;
  bottom: 2%;
  height: 90%;
  z-index: 3;
}
.chip-panel {
  position: absolute;
  top: 1%;
  left: 1%;
  bottom: 92%;
  width: 18%;
  z-index: 4;
}
.chip-panel-height {
  height: 5%;
  /* z-index: -1 !important; */
}
.chip-panel-width {
  width: 60%;
  /* z-index: -1 !important; */
}
.search-bar {
  position: absolute;
  top: 1%;
  right: 1%;
  width: 25%;
  z-index: 4;
}
.marker-save-btn {
  position: absolute;
  bottom: 2%;
  right: 2%;
  z-index: 4;
}
</style>
