<script setup>
import VCircleBtn from "@/components/common/VCircleBtn.vue";

const houseBtn = {
  img: "../src/assets/img/icon/IconHouse.png",
  text: "매물 정보",
  url: "realtyInfo",
};
const customBtn = {
  img: "../src/assets/img/icon/IconNoticeBoard.png",
  text: "게시판",
  url: "custom"
};
</script>

<template>
  <v-container fluid class="">
    <span class="background"></span>
    <v-container fluid class="d-flex">
      <v-row class="justify-space-evenly align-center">
        <VCircleBtn
          :img="houseBtn.img"
          :text="houseBtn.text"
          :url="houseBtn.url"
          :to="{ name: houseBtn.url }"
        />
        <VCircleBtn :img="customBtn.img" :text="customBtn.text" :url="custom" :to="{name: customBtn.url}"/>
      </v-row>
    </v-container>
  </v-container>
</template>

<style scoped>
.v-container::v-deep {
  height: 100%;
}
</style>
