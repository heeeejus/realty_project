<script setup>
import { ref, computed } from "vue";
import { userAuthStore } from "@/stores/auth";

const authStore = userAuthStore();
const isLogin = computed(() => !!authStore.token); //!!의 경우 해당 정보가 truthy하다면 true를 반환

defineProps(["id"]);
const activeTab = ref(`/login`);
const tabs = ref([
  { id: 1, path: "/login", name: "로그인" },
  { id: 2, path: "/signup", name: "회원가입" },
  { id: 3, path : "/reissue-password", name: "재발급"}
]);
</script>

<template>
  <v-container fluid class="h-100 ml-0 mr-0">
    <span class="background"></span>
    <v-row align="center" class="h-100 w-100">
      <v-col class="h-50 v-col-4 offset-4"
        ><v-card class="h-100 w-100 vcard" style="">
          <v-tabs
            v-model="activeTab"
            align-tabs="center"
            color="cyan-accent-4"
            text-color="cyan-accent-4"
            grow
          >
          <v-tab v-show="!isLogin" v-for="tab in tabs" :key="tab.id" :to="tab.path" exact>{{
            tab.name
          }}</v-tab>
          <v-tab v-show="isLogin">회원 정보 수정</v-tab>  
            
          </v-tabs>
          <v-container class="mt-5">
            <v-row align="center">
              <v-col>
                <router-view></router-view>
              </v-col> </v-row
          ></v-container> </v-card
      ></v-col>
    </v-row>
  </v-container>
</template>

<style scoped>
.v-tabs--density-default::v-deep {
  --v-tabs-height: 55px;
}
.vcard {
  min-height: 425px;
  min-width: 250px;
}
</style>
