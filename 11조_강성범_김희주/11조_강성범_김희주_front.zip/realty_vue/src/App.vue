<script setup>
import HeaderView from "@/components/HeaderView.vue";
import { watch } from "vue";
import { useRouter } from "vue-router";
//composition API 형식
const router = useRouter();

watch(
  () => router.currentRoute.value.name,
  (to) => {
    //console.log("현재 경로 : ", from.currentRoute.value.name);
    console.log("현재 경로 : ", to);
  },
  {
    deep: true,
  }
);
</script>

<template>
  <v-app>
    <v-layout>
      <HeaderView />
      <v-main class="fill-height">
        <RouterView></RouterView>
      </v-main>
    </v-layout>
  </v-app>
</template>

<style scoped></style>
