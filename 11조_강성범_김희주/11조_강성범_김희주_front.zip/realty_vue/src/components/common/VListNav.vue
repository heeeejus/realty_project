<script setup>
import { ref, onMounted, watch, computed } from "vue";
import VListCard from "./VListCard.vue";
import VDetailPopup from "./VDetailPopup.vue";
import { markerList } from "../../api/realty";
import { useFilterStore } from "../../stores/filter";

const filterStore = useFilterStore();

const emit = defineEmits(["infoList"]);
const props = defineProps(["markerInfo"]);

const infoList = ref([]);
const dialogs = ref({});

const realtyList = async (markerInfo) => {
  infoList.value = [];
  markerInfo.filter = JSON.parse(sessionStorage.getItem("filter"));

  console.log("marker 정보 : ", markerInfo);
  try {
    const response = await markerList(markerInfo);
    console.log(response);
    console.log(response.data);
    //infoList.value = response.data.data;
    const data = response.data.data;
    let index = 0;
    data.forEach((val, idx) => {
      const arr = val.homeSummaryInfos;
      if (arr.length != 0) {
        val.homeSummaryInfos.forEach((v, i) => {
          v.time = val.time;
          v.type = val.type;
          infoList.value[index] = v;
          index++;
        });
      }
    });
    emit("infoList", infoList.value);
    // console.log("List : ", infoList.value);
  } catch (error) {
    console.error(error);
  }
};

watch(
  () => props.markerInfo,
  (newVal, prevVal) => {
    realtyList(newVal);
  }
);

const listClick = (aptCode) => {
  // overlay.value = !overlay.value;
  //emit("overlay", overlay);
  dialogs.value[aptCode] = !dialogs.value[aptCode];
  console.log(dialogs.value);
};
const close = (dialog, aptCode) => {
  // console.log("close dialog : ");
  dialogs.value[aptCode] = dialog;
};
</script>

<template>
  <v-card class="vcard">
    <v-banner
      class="justify-center text-h6 font-weight-light text-cyan-lighten-2 vbanner"
      sticky
    >
      매물 정보 리스트
    </v-banner>
    <!-- <div class="d-flex justify-center align-center vcard-title bg-white">
      <div class="text-cyan-lighten-2">매물 정보 리스트</div>
    </div> -->
    <v-list>
      <v-list-item
        v-for="item in infoList"
        :key="item.aptCode"
        @click="() => listClick(item.aptCode)"
      >
        <VListCard :realty-data="item"></VListCard>
        <v-dialog v-model="dialogs[item.aptCode]" max-width="600px">
          <VDetailPopup
            v-if="item.aptCode"
            :apt-code="item.aptCode"
            :realtyData="item"
            v-on:close="close"
          ></VDetailPopup>
        </v-dialog>
      </v-list-item>
    </v-list>
  </v-card>
</template>

<style scoped>
.vbanner {
  z-index: 3;
}
.vcard {
  overflow: auto;
  width: 20%;
  background: rgba(189, 189, 189, 0.8);
}
.v-list::v-deep {
  background-color: transparent;
  padding: 0;
  height: 100%;
  overflow: visible;
}
.v-list-item::v-deep {
  min-height: 20%;
  padding: 0;
}

.v-list-item--density-default:not(.v-list-item--nav).v-list-item--one-line {
  padding: 5px;
}
.v-list-item__content::v-deep {
  background-color: aqua;
  height: 100%;
}
</style>
