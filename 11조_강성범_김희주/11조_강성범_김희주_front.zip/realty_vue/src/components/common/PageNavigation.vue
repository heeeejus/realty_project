<script setup>
import { ref } from "vue";

const props = defineProps({ currentPage: Number, totalPage: Number });
const emit = defineEmits(["pageChange"]);

const navigationSize = parseInt(import.meta.env.VITE_CUSTOM_NAVIGATION_SIZE);

const cp = ref();

function onPageChange() {
  console.log(cp.value + "로 이동!!!");
  emit("pageChange", cp.value);
}
</script>r

<template>
  <div class="row">
    <v-pagination
        v-model="cp"
      :value="currentPage"
      :totalPages="totalPage"
      @click="onPageChange"
      :navigationSize="navigationSize"
      :length=totalPage
    ></v-pagination>
  </div>
</template>

<style scoped>
a {
  cursor: pointer;
}
</style>
