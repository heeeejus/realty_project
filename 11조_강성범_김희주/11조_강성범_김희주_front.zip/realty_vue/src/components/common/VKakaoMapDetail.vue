<script setup>
import { onMounted, ref, watch, toRefs, onUpdated } from "vue";
import { markerList } from "../../api/realty";
import { useMarkerStore } from "../../stores/markers";

const markerStore = useMarkerStore();
const markers = markerStore.markers;

const emit = defineEmits(["markerInfo"]);
const props = defineProps(["markerInfo", "position"]);

//지도
const container = ref(null); //<div id="map"> 엘리먼트 객체
const map = toRefs(null); //kakaoMap 객체 => ref 에서 toRefs로 변경 해줘야 무한 랜더링 발생 x
let circles = [];
let realtyMarkers = [];

//최초에 javascript 파일 가져올 때만 실행될 메소드
const loadScript = () => {
  const script = document.createElement("script");
  script.src = `//dapi.kakao.com/v2/maps/sdk.js?appkey=${
    import.meta.env.VITE_KAKAO_MAP_SERVICE_KEY
  }&autoload=false`;
  script.onload = () => kakao.maps.load(loadMap);
  document.head.appendChild(script);
};

//지도 불러오는 메소드
const loadMap = () => {
  //1.지도 출력
  console.log("지도 출력 ", props.markerInfo.lat);
  const options = {
    center: new kakao.maps.LatLng(props.markerInfo.lat, props.markerInfo.lng),
    level: 3,
  };
  map.value = new kakao.maps.Map(container.value, options);

  //2. 마커 찍기
  const marker = new kakao.maps.Marker({
    position: map.value.getCenter(),
  });
  marker.setMap(map.value);

  // 지도에 표시할 원을 생성합니다
  //type에 맞는 circle 정보 가져오기
  //setCircle(markerInfo.value.filter.transportations);
  let trans = props.markerInfo.filter.transportations;
  let markers = markerStore.markers;
  console.log(trans);
  trans.forEach((val, idx) => {
    markers.forEach((v) => {
      if (v.type == val.type.toLowerCase() && v.time == val.time) {
        // console.log(v.type, v.time, val.type, val.time);
        //center 설정
        v.circle.center = new kakao.maps.LatLng(
          props.markerInfo.lat,
          props.markerInfo.lng
        );

        circles.push(new kakao.maps.Circle(v.circle));
      }
    });
  });
  //원그려주기
  for (var i = 0; i < circles.length; i++) {
    circles[i].setMap(map.value);
  }
  circles.forEach((val) => {
    val.setMap(map.value);
  });

  // 마커 이미지의 이미지 주소입니다
  var imageSrc =
    "https://t1.daumcdn.net/localimg/localimages/07/mapapidoc/markerStar.png";

  if (props.position) {
    try {
      for (let i = 0; i < props.position.length; i++) {
        // 마커 이미지의 이미지 크기 입니다
        const imageSize = new kakao.maps.Size(24, 35);

        // 마커 이미지를 생성합니다
        const markerImage = new kakao.maps.MarkerImage(imageSrc, imageSize);

        // 마커를 생성합니다
        realtyMarkers.push(
          new kakao.maps.Marker({
            //map: map.value, // 마커를 표시할 지도
            position: new kakao.maps.LatLng(
              props.position[i].lat,
              props.position[i].lng
            ), // 마커를 표시할 위치
            title: props.position[i].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
            image: markerImage, // 마커 이미지
          })
        );
      }

      realtyMarkers.forEach((val) => {
        val.setMap(map.value);
      });
    } catch (error) {
      console.error("Error parsing JSON:", error);
    }
  } else {
    console.error("No valid JSON data in sessionStorage");
  }
};

onUpdated(() => {
  loadMap();
  // if (window.kakao && window.kakao.maps) loadMap();
  // else loadScript();
});
</script>

<template>
  <div ref="container" id="map"></div>
</template>

<style scoped>
#map {
  padding: 0;
  width: 100%;
  height: 100%;
}
</style>
