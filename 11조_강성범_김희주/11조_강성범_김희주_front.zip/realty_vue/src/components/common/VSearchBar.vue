<script setup>
import { ref } from "vue";

const cardShow = ref(false);
const onClick = () => {
  console.log("검색중");
  //cardShow.value = !cardShow.value;
  //emit("cardShow", cardShow.value);
};
</script>

<template>
  <v-card class="mx-auto" color="#4DD0E1" max-width="400">
    <v-card-text>
      <v-text-field
        :loading="loading"
        density="compact"
        variant="solo"
        label="검색"
        append-inner-icon="mdi-magnify"
        single-line
        hide-details
        @click:append-inner="onClick"
      ></v-text-field>
    </v-card-text>
  </v-card>
</template>

<style scoped>
.v-card-text::v-deep {
  padding: 2px;
}
</style>
