<script setup>
import { ref } from "vue";
import VChipCardArea from "./ChipCard/VChipCardArea.vue";
import VChipCardTrans from "./ChipCard/VChipCardTrans.vue";
import VChipCardDate from "./ChipCard/VChipCardDate.vue";
import VChipCardDeal from "./ChipCard/VChipCardDeal.vue";
const emit = defineEmits(["cardShow"]);
const props = defineProps(["chipName", "disable", "markerInfo"]);

const cardShow = ref(false);
const dropdown = () => {
  cardShow.value = !cardShow.value;
  emit("cardShow", cardShow.value);
};
</script>

<template>
  <v-container>
    <v-container>
      <v-chip variant="outlined" color="#4DD0E1">
        <span class="text-white">{{ props.chipName }}</span>
        <v-icon class="text-white" @click="dropdown">$dropdown</v-icon>
      </v-chip>
    </v-container>
    <v-container>
      <VChipCardArea
        v-if="cardShow && chipName == '면적'"
        :card-show="cardShow"
        :disable="props.disable"
        :markerInfo="markerInfo"
      ></VChipCardArea>
      <VChipCardDate
        v-if="cardShow && chipName == '거래일'"
        :card-show="cardShow"
        :disable="props.disable"
        :markerInfo="markerInfo"
      ></VChipCardDate>
      <VChipCardDeal
        v-if="cardShow && chipName == '거래가격'"
        :card-show="cardShow"
        :disable="props.disable"
        :markerInfo="markerInfo"
      ></VChipCardDeal>
      <VChipCardTrans
        v-if="cardShow && chipName == '도보/자전거'"
        :card-show="cardShow"
        :disable="props.disable"
        :markerInfo="markerInfo"
      ></VChipCardTrans>
      <!-- <v-card v-show="cardShow">카드폼</v-card> -->
    </v-container>
  </v-container>
  <!-- 필터 초기화 버튼있으면 좋을 듯 -->
</template>

<style scoped>
.v-container::v-deep {
  padding: 0;
  width: 100%;
}
.v-chip::v-deep {
  background-color: #4dd0e1;
  margin-bottom: 1px;
}
.v-chip-card {
  z-index: 3;
  /* height: 300px;
  overflow-y: auto; */
}
.card-show-width {
  width: 110px;
}
</style>
