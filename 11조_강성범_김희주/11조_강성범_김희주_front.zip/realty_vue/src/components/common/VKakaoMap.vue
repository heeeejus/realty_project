<script setup>
import { onMounted, ref, watch, toRefs } from "vue";
import { markerList } from "../../api/realty";
import { useMarkerStore } from "../../stores/markers";

const markerStore = useMarkerStore();
const markers = markerStore.markers;

const emit = defineEmits(["markerInfo"]);
const props = defineProps(["markerInfo", "position"]);

const searchKeyword = ref();
const searchSuccessData = ref();
const searchSuccessPage = ref();

const isShowSearchList = ref(true);

//지도
const container = ref(null); //<div id="map"> 엘리먼트 객체
const map = toRefs(null); //kakaoMap 객체 => ref 에서 toRefs로 변경 해줘야 무한 랜더링 발생 x
let circles = [];
let realtyMarkers = [];

//marker 정보
const markerInfo = ref({
  address: "",
  filter: {
    area: {
      lower: 0,
      upper: 0,
    },
    date: {
      lower: "",
      upper: "",
    },
    dealAmount: {
      lower: 0,
      upper: 0,
    },
    transportations: [
      {
        time: 0,
        type: "",
      },
    ],
  },
  lat: 0,
  lng: 0,
});

//최초에 javascript 파일 가져올 때만 실행될 메소드
const loadScript = () => {
  const script = document.createElement("script");
  script.src = `//dapi.kakao.com/v2/maps/sdk.js?appkey=${
    import.meta.env.VITE_KAKAO_MAP_SERVICE_KEY
  }&autoload=false`;
  script.onload = () => kakao.maps.load(loadMap());
  document.head.appendChild(script);
};

//지도 불러오는 메소드
const loadMap = (isLoad) => {
  //1.지도 출력
  const options = {
    center: new kakao.maps.LatLng(37.53285533626674, 126.97271082226248),
    level: 3,
  };
  map.value = new kakao.maps.Map(container.value, options);

  //2. 마커 찍기
  const sessionMarkerInfo = JSON.parse(sessionStorage.getItem("markerInfo"));
  console.log(sessionMarkerInfo);
  const marker = new kakao.maps.Marker({
    position: map.value.getCenter(),
  });
  marker.setMap(map.value);

  // // 지도에 표시할 원을 생성합니다
  // markers[0].circle.center = new kakao.maps.LatLng(
  //   37.53285533626674,
  //   126.97271082226248
  // );
  // var circle = new kakao.maps.Circle(markers[0].circle);

  // 지도에 원을 표시합니다
  // circle.setMap(map.value);
  //circle.setMap(); 영역 없애기

  //3. 지도 click 이벤트 핸들링
  kakao.maps.event.addListener(map.value, "click", (mouseEvent) => {
    //마커, 영역 정보 초기화
    markerClear();
    //circle.setMap();
    circles.forEach((val) => {
      val.setMap();
    });
    circles = [];
    realtyMarkers.forEach((val) => {
      val.setMap();
    });
    realtyMarkers = [];

    // 클릭한 위도, 경도 정보를 가져옵니다
    const latlng = mouseEvent.latLng;

    //좌표 값에 해당하는 구 주소와 도로명 주소 가져오기
    const geocoder = new kakao.maps.services.Geocoder();

    const callback = function (result, status) {
      if (status === kakao.maps.services.Status.OK) {
        //markerInfo 세팅
        markerInfo.value.address = result[0].address.address_name;
        markerInfo.value.lat = latlng.getLat();
        markerInfo.value.lng = latlng.getLng();
        // 마커 위치를 클릭한 위치로 옮깁니다
        marker.setPosition(latlng);
        console.log("마커 정보 : ", markerInfo.value);
        emit("markerInfo", markerInfo.value);

        //type에 맞는 circle 정보 가져오기
        //setCircle(markerInfo.value.filter.transportations);
        let trans = markerInfo.value.filter.transportations;
        let markers = markerStore.markers;
        trans.forEach((val, idx) => {
          markers.forEach((v) => {
            if (v.type == val.type && v.time == val.time) {
              // console.log(v.type, v.time, val.type, val.time);
              //center 설정
              v.circle.center = new kakao.maps.LatLng(
                markerInfo.value.lat,
                markerInfo.value.lng
              );

              circles.push(new kakao.maps.Circle(v.circle));
            }
          });
        });
        //원그려주기
        for (var i = 0; i < circles.length; i++) {
          circles[i].setMap(map.value);
        }
        circles.forEach((val) => {
          val.setMap(map.value);
        });
      }
    };
    geocoder.coord2Address(latlng.getLng(), latlng.getLat(), callback);
  });
};

// 검색창
const ps = new kakao.maps.services.Places();

const searchPlaces = () => {
  if (!searchKeyword.value.replace(/^\s+|\s+$/g, "")) {
    alert("키워드를 입력해주세요!");
    return false;
  }
  // 장소검색 객체를 통해 키워드로 장소검색을 요청합니다
  ps.keywordSearch(searchKeyword.value, placesSearchCB);
};

const placesSearchCB = (data, status, pagination) => {
  if (status === kakao.maps.services.Status.OK) {
    console.log("검색 성공"); // 검색 성공
    console.log("data : ", data);
    console.log("pagination : ", pagination);

    searchSuccessData.value = data;
    searchSuccessPage.value = pagination;
  } else if (status === kakao.maps.services.Status.ZERO_RESULT) {
    alert("검색 결과가 존재하지 않습니다.");
    return;
  } else if (status === kakao.maps.services.Status.ERROR) {
    alert("검색 결과 중 오류가 발생했습니다.");
    return;
  }
};

const moveMap = (lat, lng) => {
  console.log(`lat : ${lat}, lng : ${lng}로 이동합니다.`);
  map.value.setCenter(new kakao.maps.LatLng(lat, lng));
};

const toggleSwitch = () => {
  isShowSearchList.value = !isShowSearchList.value;
};

watch(
  () => props.markerInfo,
  (markerInfo) => {
    //marker.setPosition(latlng);

    let trans = markerInfo.filter.transportations;
    let markers = markerStore.markers;
    trans.forEach((val, idx) => {
      markers.forEach((v) => {
        if (v.type == val.type && v.time == val.time) {
          // console.log(v.type, v.time, val.type, val.time);
          //center 설정
          v.circle.center = new kakao.maps.LatLng(
            markerInfo.lat,
            markerInfo.lng
          );

          circles.push(new kakao.maps.Circle(v.circle));
        }
      });
    });
    //원그려주기
    for (var i = 0; i < circles.length; i++) {
      circles[i].setMap(map.value);
    }
    circles.forEach((val) => {
      val.setMap(map.value);
    });
  }
);

watch(
  () => props.position,
  (newVal, prevVal) => {
    // 마커 이미지의 이미지 주소입니다
    var imageSrc =
      "https://t1.daumcdn.net/localimg/localimages/07/mapapidoc/markerStar.png";

    if (newVal) {
      try {
        for (let i = 0; i < newVal.length; i++) {
          // 마커 이미지의 이미지 크기 입니다
          const imageSize = new kakao.maps.Size(24, 35);

          // 마커 이미지를 생성합니다
          const markerImage = new kakao.maps.MarkerImage(imageSrc, imageSize);

          // 마커를 생성합니다
          realtyMarkers.push(
            new kakao.maps.Marker({
              //map: map.value, // 마커를 표시할 지도
              position: new kakao.maps.LatLng(newVal[i].lat, newVal[i].lng), // 마커를 표시할 위치
              title: newVal[i].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
              image: markerImage, // 마커 이미지
            })
          );
        }

        realtyMarkers.forEach((val) => {
          val.setMap(map.value);
        });
      } catch (error) {
        console.error("Error parsing JSON:", error);
      }
    } else {
      console.error("No valid JSON data in sessionStorage");
    }
  }
);

onMounted(() => {
  if (window.kakao && window.kakao.maps) loadMap();
  else loadScript();
});

//마커 정보 초기화 메소드
const markerClear = () => {
  markerInfo.value = {
    address: "",
    filter: {
      area: {
        lower: 0,
        upper: 0,
      },
      date: {
        lower: "",
        upper: "",
      },
      dealAmount: {
        lower: 0,
        upper: 0,
      },
      transportations: [,],
    },
    lat: 0,
    lng: 0,
  };
};
</script>

<template>
  <div ref="container" id="map"></div>
  <div class="search-div">
    <div class="search-elements">
      <div class="searh-text-list">
        <div class="search-text-div">
          <v-text-field
            class="search-text"
            label="장소"
            variant="solo"
            v-model="searchKeyword"
            v-on:keyup.enter="searchPlaces()"
          ></v-text-field>
        </div>
        <ul v-if="isShowSearchList" id="placesList">
          <li
            class="search-list-item"
            v-for="(item, index) in searchSuccessData"
            :key="index"
            @click="moveMap(item.y, item.x)"
          >
            <v-card>{{ item.place_name }}</v-card>
          </li>
        </ul>
      </div>
      <div>
        <v-btn class="search-btn" v-on:click="searchPlaces()">검색</v-btn>

        <input type="checkbox" id="toggle" hidden />
        <label for="toggle" class="toggleSwitch" @click="toggleSwitch()">
          <span class="toggleButton"></span>
        </label>
      </div>
    </div>
  </div>
</template>

<style scoped>
#map {
  padding: 0;
  width: 100%;
  height: 100%;
}

.search-div {
  position: absolute;
  z-index: 1000;
  top: 50px;
  right: 20px;
}

.search-elements {
  display: flex;
  flex-direction: row;
  height: 100%;
  width: 250px;
}

.search-text-div {
  height: 56px;
}

.search-text {
  width: 100%;
  height: 100%;
}

.searh-text-list {
  display: flex;
  flex-direction: column;
  width: 100%;
  z-index: 1000;
}

.search-list-item {
  margin: 2px;
}

.search-list-item:hover {
  cursor: pointer;
}

#placesList {
  width: 100%;
  list-style-type: none;
  font-size: 0.9em;
  background-color: #ffffffaa;
}

.v-input__details {
  height: 0px;
}

.search-btn {
  margin-left: 1.5px;
  height: 56px;
}

.toggleSwitch {
  width: 25px;
  height: 16px;
  display: block;
  position: relative;
  border-radius: 30px;
  background-color: #fff;
  box-shadow: 0 0 16px 3px rgba(0 0 0 / 15%);
  cursor: pointer;
  margin: 10px 10px 0 20px;
}

.toggleSwitch .toggleButton {
  width: 10px;
  height: 10px;
  position: absolute;
  top: 50%;
  left: 4px;
  transform: translateY(-50%);
  border-radius: 50%;
  background: #f03d3d;
}

#toggle:checked ~ .toggleSwitch {
  background: #f03d3d;
}

#toggle:checked ~ .toggleSwitch .toggleButton {
  left: calc(100% - 14px);
  background: #fff;
}

.toggleSwitch,
.toggleButton {
  transition: all 0.2s ease-in;
}
</style>
