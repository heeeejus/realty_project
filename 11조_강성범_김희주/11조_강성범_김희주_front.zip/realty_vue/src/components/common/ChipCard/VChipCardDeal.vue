<script setup>
import { ref, watch, onBeforeMount } from "vue";
import { useFilterStore } from "../../../stores/filter";
const props = defineProps(["disable", "markerInfo", "cardShow"]);
const filterStore = useFilterStore();

const sliderValue = ref(0);

watch(
  () => sliderValue.value,
  (newVal, prevVal) => {
    if (props.disable == false) {
      console.log("변경 거래가 : ", newVal);
      filterStore.filter.dealAmount.upper = newVal;
      console.log("filter 거래가 : ", filterStore.filter.dealAmount.upper);
      filterStore.sessionFilterUpdate(filterStore.filter);
    }
  }
);

const setData = () => {
  if (props.disable == true) {
    const trans = props.markerInfo.filter.dealAmount;
    sliderValue.value = trans.upper;
  }
};

onBeforeMount(() => {
  setData();
});
</script>

<template>
  <v-card :class="{ 'card-show': cardShow }">
    <v-card-item>
      <div>
        <!-- 제목 : 방종류 -->
        <div class="text-subtitle-1 mb-1">거래가(억)</div>
        <!-- 스케일  -->
        <v-container>
          <v-slider
            v-model="sliderValue"
            thumb-label="always"
            :disabled="props.disable"
            max="2000"
          ></v-slider>
        </v-container>
      </div>
    </v-card-item>
    <v-card-actions>
      <!-- 버튼 -->
      <v-btn
        variant="outlined"
        color="#4DD0E1"
        class="clear-btn offset-9"
        :disabled="disable"
      >
        clear
      </v-btn>
    </v-card-actions>
  </v-card>
</template>

<style scoped>
.v-container::v-deep {
  padding: 0;
}
.v-col::v-deep {
  padding: 5px;
}
.v-card::v-deep {
  height: 100%;
  overflow: auto;
}
.v-slider::v-deep {
  width: 90%;
  padding: 20px 0px 5px 15px;
}
.slider-title::v-deep {
  margin-top: 10px;
}
.clear-btn {
}
.card-show {
  width: 300px;
}
</style>
