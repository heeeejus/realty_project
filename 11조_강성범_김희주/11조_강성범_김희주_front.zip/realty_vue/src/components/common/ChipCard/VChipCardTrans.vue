<script setup>
import { ref, watch, onBeforeMount } from "vue";
import { useFilterStore } from "../../../stores/filter";
const props = defineProps(["disable", "markerInfo", "cardShow"]);
const filterStore = useFilterStore();

const checkBoxValue = ref([]);
watch(
  () => checkBoxValue.value,
  (newVal, prevVal) => {
    if (props.disable == false) {
      console.log(checkBoxValue.value);
      console.log("변경 : ", newVal);
      const tmp = [];
      newVal.forEach((val, idx) => {
        const str = val.split("/");
        const obj = {
          time: parseInt(str[0]),
          type: str[1],
        };

        tmp[idx] = obj;
      });
      console.log(checkBoxValue.value);
      console.log("객체 trans: ", tmp);
      filterStore.filter.transportations = tmp;
      console.log("filter  : ", filterStore.filter.transportations);
      filterStore.sessionFilterUpdate(filterStore.filter);
    }
  }
);

const setData = () => {
  if (props.disable == true) {
    const trans = props.markerInfo.filter.transportations;
    console.log(checkBoxValue.value);
    trans.forEach((val) => {
      const tmp = `${val.time}/${val.type}`;
      checkBoxValue.value.push(tmp);
    });
    console.log(checkBoxValue.value);
  } else if (props.disable == false) {
    const trans = [{ time: 5, type: "walk" }];
    console.log(checkBoxValue.value);
    trans.forEach((val) => {
      const tmp = `${val.time}/${val.type}`;
      checkBoxValue.value.push(tmp);
    });
    console.log(checkBoxValue.value);
  }
};

onBeforeMount(() => {
  setData();
});

const selectLabel = [
  {
    id: 1,
    trans: "도보",
    type: "walk",
    time: 5,
  },
  {
    id: 2,
    trans: "도보",
    type: "walk",
    time: 10,
  },
  {
    id: 3,
    trans: "도보",
    type: "walk",
    time: 15,
  },
  {
    id: 4,
    trans: "자전거",
    type: "bicycle",
    time: 5,
  },
  {
    id: 5,
    trans: "자전거",
    type: "bicycle",
    time: 10,
  },
  {
    id: 6,
    trans: "자전거",
    type: "bicycle",
    time: 15,
  },
];
</script>

<template>
  <v-card :class="{ 'card-show': cardShow }">
    <v-card-item>
      <div>
        <!-- 제목 : 방종류 -->
        <div class="text-subtitle-1 mb-1">방종류</div>
        <!-- 체크박스 영역  -->
        <v-container class="text-caption check-box">
          <v-row>
            <v-col>
              <v-checkbox
                :disabled="props.disable"
                v-for="item in selectLabel"
                :key="item.id"
                v-model="checkBoxValue"
                :label="item.trans + '/' + item.time"
                color="#4DD0E1"
                :value="item.time + '/' + item.type"
                hide-details
              ></v-checkbox>
            </v-col>
          </v-row>
        </v-container>
        <v-divider class="border-opacity-25"></v-divider>
      </div>
    </v-card-item>
    <v-card-actions>
      <!-- 버튼 -->
      <v-btn
        variant="outlined"
        color="#4DD0E1"
        class="clear-btn offset-9"
        :disabled="props.disable"
      >
        clear
      </v-btn>
    </v-card-actions>
  </v-card>
</template>

<style scoped>
.v-container::v-deep {
  padding: 0;
}
.v-col::v-deep {
  padding: 5px;
}
.v-card::v-deep {
  height: 100%;
  overflow: auto;
}
.v-checkbox::v-deep {
  height: 12%;
}
.check-box {
  height: 250px;
}
.radio-box {
  height: 120px;
  padding-top: 15px;
  margin-bottom: 15px;
}
.clear-btn {
}
.card-show {
  width: 300px;
}
</style>
