<script setup>
import { ref } from "vue";

const checkBoxValue = ref([]);
const radioValue = ref("");
const sliderValue = ref(0);
</script>

<template>
  <v-card>
    <v-card-item>
      <div>
        <!-- 제목 : 방종류 -->
        <div class="text-subtitle-1 mb-1">면적</div>
        <!-- 체크박스 영역  -->
        <v-container class="text-caption check-box">
          <v-row>
            <v-col>
              <v-checkbox
                v-model="checkBoxValue"
                label="원룸"
                color="#4DD0E1"
                value="원룸"
                hide-details
              ></v-checkbox>
              <v-checkbox
                v-model="checkBoxValue"
                label="투/쓰리룸"
                color="#4DD0E1"
                value="투/쓰리룸"
                hide-details
              ></v-checkbox>
              <v-checkbox
                v-model="checkBoxValue"
                label="오피스텔/도시형생활주택"
                color="#4DD0E1"
                value="오피스텔/도시형생활주택"
                hide-details
              ></v-checkbox>
            </v-col>
          </v-row>
        </v-container>
        <v-divider class="border-opacity-25"></v-divider>
        <!-- radio박스 영역  -->
        <v-container class="text-caption radio-box">
          <v-row>
            <v-col>
              <v-radio-group v-model="radioValue">
                <v-radio
                  label="Radio One"
                  color="#4DD0E1"
                  value="one"
                ></v-radio>
                <v-radio
                  label="Radio Two"
                  color="#4DD0E1"
                  value="two"
                ></v-radio>
                <v-radio
                  label="Radio Three"
                  color="#4DD0E1"
                  value="three"
                ></v-radio>
              </v-radio-group>
            </v-col>
          </v-row>
        </v-container>
        <v-divider class="border-opacity-25"></v-divider>
        <!-- 스케일  -->
        <v-container>
          <div class="text-subtitle-2 slider-title">가격</div>
          <v-slider v-model="sliderValue" thumb-label="always"></v-slider>
        </v-container>
      </div>
    </v-card-item>
    <v-card-actions>
      <!-- 버튼 -->
      <v-btn variant="outlined" color="#4DD0E1" class="clear-btn offset-9">
        clear
      </v-btn>
    </v-card-actions>
  </v-card>
</template>

<style scoped>
.v-container::v-deep {
  padding: 0;
}
.v-col::v-deep {
  padding: 5px;
}
.v-card::v-deep {
  height: 100%;
  overflow: auto;
}
.v-checkbox::v-deep {
  height: 17%;
}
.check-box {
  height: 120px;
}
.radio-box {
  height: 120px;
  padding-top: 15px;
  margin-bottom: 15px;
}
.v-slider::v-deep {
  width: 90%;
  padding: 20px 0px 5px 15px;
}
.slider-title::v-deep {
  margin-top: 10px;
}
.clear-btn {
}
</style>
