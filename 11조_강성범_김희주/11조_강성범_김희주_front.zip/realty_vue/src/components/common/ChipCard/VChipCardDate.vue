<script setup>
import { ref, watch, onBeforeMount } from "vue";
import { useDate } from "vuetify";
import { useFilterStore } from "../../../stores/filter";
const props = defineProps(["disable", "markerInfo", "cardShow"]);
const filterStore = useFilterStore();

//startDate, endDate 유효성 검사

const offset = new Date().getTimezoneOffset() * 60000;
const today = new Date();
const startDate = ref(today);
const pickStartDate = ref(new Date(today).toISOString().substr(0, 10));
const endDate = ref(today);
const pickEndDate = ref(new Date(today).toISOString().substr(0, 10));

watch(
  () => startDate.value,
  (newVal, prevVal) => {
    if (props.disable == false) {
      pickStartDate.value = new Date(newVal - offset)
        .toISOString()
        .substr(0, 10);
      console.log("변경 날짜 : ", pickStartDate.value);
      filterStore.filter.date.lower = pickStartDate.value;
      console.log("filter 날짜 : ", filterStore.filter.date.lower);
      filterStore.sessionFilterUpdate(filterStore.filter);
    }
  }
);
watch(
  () => endDate.value,
  (newVal, prevVal) => {
    if (props.disable == false) {
      pickEndDate.value = new Date(newVal - offset).toISOString().substr(0, 10);
      console.log("변경 날짜 : ", pickEndDate.value);
      filterStore.filter.date.upper = pickEndDate.value;
      console.log("filter 날짜 : ", filterStore.filter.date.upper);
      filterStore.sessionFilterUpdate(filterStore.filter);
    }
  }
);

const menu = ref(false);
const menu2 = ref(false);

const setData = () => {
  if (props.disable == true) {
    const trans = props.markerInfo.filter.date;
    startDate.value = trans.lower;
    pickStartDate.value = trans.lower;
    endDate.value = trans.upper;
    pickEndDate.value = trans.upper;
  }
};

onBeforeMount(() => {
  setData();
});
</script>

<template>
  <v-card :class="{ 'card-show': cardShow }">
    <v-card-item>
      <div>
        <!-- 제목 : 방종류 -->
        <div class="text-subtitle-1 mb-1">거래일</div>
        <v-flex xs12 sm6 md4>
          <v-menu
            v-model="menu"
            :close-on-content-click="false"
            :nudge-right="40"
            lazy
            transition="scale-transition"
            offset-y
            full-width
            min-width="290px"
          >
            <template v-slot:activator="{ on }">
              <v-text-field
                :disabled="props.disable"
                v-model="pickStartDate"
                label="start-date"
                prepend-icon="event"
                readonly
                @click="menu = !menu"
                location="center"
              ></v-text-field>
            </template>
            <v-date-picker
              color="primary"
              v-model="startDate"
              @input="menu = false"
            >
            </v-date-picker>
          </v-menu>
          <v-menu
            v-model="menu2"
            :close-on-content-click="false"
            :nudge-right="40"
            lazy
            transition="scale-transition"
            offset-y
            full-width
            min-width="290px"
          >
            <template v-slot:activator="{ on }">
              <v-text-field
                :disabled="disable"
                v-model="pickEndDate"
                label="end-date"
                prepend-icon="event"
                readonly
                @click="menu2 = !menu2"
                location="center"
              ></v-text-field>
            </template>
            <v-date-picker
              color="primary"
              v-model="endDate"
              @input="menu2 = false"
            >
            </v-date-picker>
          </v-menu>
        </v-flex>
      </div>
    </v-card-item>
    <v-card-actions>
      <!-- 버튼 -->
      <v-btn
        v-show="false"
        variant="outlined"
        color="#4DD0E1"
        class="clear-btn offset-9"
        :disabled="props"
      >
        clear
      </v-btn>
    </v-card-actions>
  </v-card>
</template>

<style scoped>
.v-container::v-deep {
  padding: 0;
}
.v-col::v-deep {
  padding: 5px;
}
.v-card::v-deep {
  height: 100%;
  overflow: auto;
}
.clear-btn {
}
.card-show {
  width: 300px;
}
</style>
