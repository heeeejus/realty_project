<script setup>
import { ref } from "vue";
// import img from "@/assets/img/house.jpg";

defineProps({ img: String, text: String, url: String });
//const img = ref(require("@/assets/img/house.jpg"));
</script>

<template>
  <v-card class="vcard-circle">
    <div class="vcard-circle d-flex justify-center flex-column bg-white">
      <img :src="img" class="vcirclebtn-img align-self-center mb-2" />
      <v-sheet class="mt-2 mb-3 align-selft-center text-center">
        <RouterLink
          :to="{ name: url }"
          class="vcard-link text-cyan-lighten-3"
          >{{ text }}</RouterLink
        >
      </v-sheet>
    </div>
  </v-card>
</template>

<style scoped>
.v-sheet::v-deep {
  background: transparent;
}
.vcard-circle {
  width: 300px;
  height: 300px;
  border-radius: 50%;
}
.vsheet-circle {
  width: 150px;
  height: 150px;
  border-radius: 50%;
}

.vcirclebtn-img {
  width: 100px;
  /* height: 150px; */
  /* border-radius: 50%; */
}
.vcard-link {
  text-decoration: none;
  font-size: x-large;
  font-weight: 500;
}
</style>
