<script setup>
import { ref, onMounted } from "vue";
import { aptDealList } from "../../api/realty";
import Chart from "chart.js/auto"

const emit = defineEmits(["close"]);
const props = defineProps(["aptCode", "realtyData"]);

const close = ref(false);
const dealList = ref(); // 거래 정보
const viewAllDetailInfo = ref(false);

const closeEvent = () => {
  emit("close", close, props.aptCode);
};

const toggleViewAllDetailInfo = () => {
  viewAllDetailInfo.value = !viewAllDetailInfo.value;
}

const aptDetail = async () => {
  try {
    const response = await aptDealList(props.aptCode);
    dealList.value = response.data;
    console.log("dealList 정보", dealList.value);
  } catch (error) {
    console.error(error);
  }
};

const numberWithUnit = (value) => {
  if (!value) return '';
  
  let newValue = value;
  if (value >= 100000000) {
    newValue = (value / 100000000).toFixed(1) + '억';
  } else if (value >= 10000) {
    newValue = (value / 10000).toFixed(1) + '만';
  } else if (value >= 1000) {
    newValue = (value / 1000).toFixed(1) + '천';
  }
  
  return newValue;
};

const dealChartCanvas = ref();

const createDealChart = () => {
  if (!dealChartCanvas.value || !dealList.value) return;

  const years = dealList.value.data.map(item => item.dealDate.split('-')[0]);
  const yearCount = years.reduce((acc, year) => {
    acc[year] = (acc[year] || 0) + 1;
      return acc;
    }, {}
  );

  const labels = Object.keys(yearCount);
  const data = Object.values(yearCount);


  new Chart(dealChartCanvas.value, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [{
        label: '연도별 거래 수',
        data: data,
        backgroundColor: 'rgba(54, 162, 235, 0.5)',
        borderColor: 'rgba(54, 162, 235, 1)',
        borderWidth: 1
      }]
    },
    options: {
      scales: {
        y: {
          beginAtZero: true
        }
      }
    }
  });
}

onMounted(async () => {
  await aptDetail();
  
  createDealChart();
  
});
</script>

<template>
  <v-card class>
    <div class="d-flex flex-no-wrap justify-space-between">
      <div class="v-col-7">  
        <v-card-title class="text-h5">부동산 상세 거래 정보</v-card-title>
        <v-card-subtitle v-if="dealList"> 건물 이름 : {{
          dealList.apartmentName
        }}</v-card-subtitle>
        <v-card-text v-if="dealList">주소 : {{ dealList.address }}</v-card-text>
        <v-card-text v-if="dealList">총 거래 수 : {{ props.realtyData.totalDealAmount }}</v-card-text>
        <v-card-text v-if="dealList">최대 거래 가격 : {{ numberWithUnit(props.realtyData.maxDealAmount * 10000) }}</v-card-text>
        <v-card-text v-if="dealList">최소 거래 가격 : {{ numberWithUnit(props.realtyData.minDealAmount * 10000) }}</v-card-text>
        <v-card-text v-if="dealList">평균 거래 면적 : {{ Number(props.realtyData.avgArea).toFixed(4) }}m³</v-card-text>
      </div>
      <div class="v-col-5" v-if="googleKey != null">
      
      </div>
    </div>
    
    <div v-if="dealList">
      <canvas style="height: 200px;" ref="dealChartCanvas"></canvas>

      <v-btn variant="outlined" class="view-all-detail-info-btn" @click="toggleViewAllDetailInfo">상세 거래 정보 보기</v-btn>
      <div class="view-all-detail-info" v-if="viewAllDetailInfo">
        <v-card class="a-house-detail-deal-info" v-for="(item, index) in dealList.data" :key="index">
          <v-card-text cla>층 : {{item.floor}}</v-card-text>
          <v-card-text>거래 금액 : {{numberWithUnit(item.dealAmount)}}</v-card-text>
          <v-card-text>거래 날짜 : {{item.dealDate}}</v-card-text>
        </v-card>
      </div>
    </div>

    <v-btn color="success" @click="closeEvent"> Hide Overlay </v-btn>
  </v-card>
</template>

<style scoped>
.a-house-detail-deal-info{
  border: 1px solid #ccc;
  border-radius: 4px;
  margin-bottom: 5px;
}
.a-house-detail-deal-info > *{
  margin: 5px;
  padding: 0px;
}
.v-dialog > .v-overlay__content > .v-card > .v-card-text{
  padding :5px 10px;
}

.view-all-detail-info-btn{
  width: 100%;
}

.view-all-detail-info{
  height: 300px;
  overflow-y: auto;
}

</style>
