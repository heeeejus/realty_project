<script setup>
import { ref } from "vue";
import { customLike } from "../../api/custom";
import { useRouter } from "vue-router";

const router = useRouter();

const props = defineProps(["customId"]);
const isLike = ref(false);
const icon = ref("mdi-heart-outline");

const markerLike = async () => {
  console.log(props.customId);
  customLike(
    props.customId,
    (response) => {
      isLike.value = !isLike.value;

      if(isLike.value == true){
        icon.value="mdi-heart";
      }else {
        icon.value="mdi-heart-outline";
      }
      
    },
    (error) => {
      alert('error');
    }
  );
    
  
};
</script>

<template>
  <div>
    <v-btn
      class="text-white"
      :icon="icon"
      size="x-large"
      color="#4DD0E1"
      title="Custom 마커 좋아요"
      @click="markerLike"
    ></v-btn>
  </div>
</template>

<style scoped>
.v-text-field::v-deep {
  width: 380px;
}
.v-input::v-deep {
  padding-top: 20px;
}
.v-card-text::v-deep {
  padding: 5px;
}
.btn {
  width: 100px;
}
</style>
