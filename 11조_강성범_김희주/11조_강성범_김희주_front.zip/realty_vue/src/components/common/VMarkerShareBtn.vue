<script setup>
import { ref } from "vue";
import { useFilterStore } from "../../stores/filter";
import { useMarkerStore } from "../../stores/markers";
import { markerShareSave, markerShareList } from "../../api/realty";
import { useRouter } from "vue-router";

const filterStore = useFilterStore();
const markerStore = useMarkerStore();
const router = useRouter();

const props = defineProps(["markerInfo"]);
const dialog = ref(false);
const title = ref("");

const markerShare = async () => {
  //마커 임시저장 후 매물 정보페이지 이동해서
  console.log("임시저장 마커 정보 ", props.markerInfo);
  try {
    let markerInfos = "";
    props.markerInfo.filter = JSON.parse(sessionStorage.getItem("filter"));
    console.log("마커 저장 정보 :", props.markerInfo);
    markerInfos = `{"markers" : [${JSON.stringify(props.markerInfo)}]}`;
    const response = await markerShareSave(JSON.parse(markerInfos));
    try {
      const response = await markerShareList();
      console.log("markerShareList : ", response.data);
      const markerInfo = response.data;
      markerStore.markerInfo = markerInfo;
      sessionStorage.setItem("markerInfo", JSON.stringify(markerInfo.data[0]));
      sessionStorage.setItem(
        "filter",
        JSON.stringify(markerInfo.data[0].filter)
      );
      router.push("/realtyInfo");
    } catch (error) {
      console.log(error);
      alert("error");
    }
  } catch (error) {
    alert("error");
  }
  //임시 저장된 마커 정보 페이지에서 꺼내서 세팅
};
</script>

<template>
  <div>
    <v-btn
      class="text-white"
      icon="mdi-map-marker"
      size="x-large"
      color="#4DD0E1"
      title="마커 퍼가기"
      @click="markerShare"
    ></v-btn>
  </div>
</template>

<style scoped>
.v-text-field::v-deep {
  width: 380px;
}
.v-input::v-deep {
  padding-top: 20px;
}
.v-card-text::v-deep {
  padding: 5px;
}
.btn {
  width: 100px;
}
</style>
