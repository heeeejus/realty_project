<script setup>
import { createSSRApp } from "vue";
import { onMounted } from "vue";
import { ref, watch } from "vue";
const props = defineProps(["realtyData"]);

const color = ref("#1F7087");
const src = ref("https://cdn.vuetifyjs.com/images/cards/foster.jpg");

const colorChange = () => {
  // console.log(props.realtyData);
  if (props.realtyData.type == "WALK") {
    color.value = "#1F7087";
    src.value = "https://cdn.vuetifyjs.com/images/cards/foster.jpg";
  } else if (props.realtyData.type == "BYCYCLE") {
    color.value = "#4DB6AC";
    src.value = "https://cdn.vuetifyjs.com/images/cards/road.jpg";
  }
};

const numberWithUnit = (value) => {
  if (!value) return '';
  
  let newValue = value;
  if (value >= 100000000) {
    newValue = (value / 100000000).toFixed(1) + '억';
  } else if (value >= 10000) {
    newValue = (value / 10000).toFixed(1) + '만';
  } else if (value >= 1000) {
    newValue = (value / 1000).toFixed(1) + '천';
  }
  
  return newValue;
};

const staticMap = ref();
const loadKakaoImage = () => {
  const script = document.createElement('script');
  script.src = `//dapi.kakao.com/v2/maps/sdk.js?appkey=${import.meta.env.VITE_KAKAO_MAP_SERVICE_KEY}&autoload=false`;
  document.head.appendChild(script);

  script.onload = () => {
    kakao.maps.load(() => {
      const staticMapContainer = staticMap.value;
      const staticMapOption = {
        center: new kakao.maps.LatLng(props.realtyData.lat, props.realtyData.lng),
        level: 1
      };
      
      new kakao.maps.StaticMap(staticMapContainer, staticMapOption);
    });
  };
}

onMounted(() => {
  console.log(props.realtyData);
  colorChange();
  loadKakaoImage();
});
</script>

<template>
  <v-card :color="color" theme="dark" class="listcard">
    <div class="d-flex flex-no-wrap justify-space-between">
      <div class="v-col-7">
        <v-card-title class="text-subtitle-1">{{
          props.realtyData.apartmentName
        }}</v-card-title>
        <v-card-subtitle>{{ props.realtyData.address }}</v-card-subtitle>
        <v-card-text
          >평균 면적 :
          {{ Math.round(props.realtyData.avgArea * 100) / 100 }}</v-card-text
        >
        <v-card-text
          >최대 거래가 : {{ numberWithUnit(props.realtyData.maxDealAmount*10000) }}</v-card-text
        >
      </div>
      
      <div class="v-col-5 d-flex align-center justify-center">
        <div ref="staticMap" style="width: 90px; height: 90px;"></div>
      </div>
    </div>
  </v-card>
</template>
<!--  -->
<style scoped>
.listcard {
  background: rgba(169, 169, 169, 0.8);
  height: 100%;
}
.v-card-subtitle {
  padding: 0.1rem 0.5rem;
}
.v-card-title {
  padding: 0.1rem 0.5rem;
}
.v-card-text {
  padding: 0.1rem 0.5rem;
}
</style>
