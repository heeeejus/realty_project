<script setup>
import { ref } from "vue";
import { useFilterStore } from "../../stores/filter";
import { markerSave } from "../../api/realty";
import { useRouter } from "vue-router";


const router = useRouter();
const filterStore = useFilterStore();

const props = defineProps(["markerInfo"]);
const dialog = ref(false);
const title = ref("");

const saveMarker = async () => {
  try {
    let markerInfos = "";
    props.markerInfo.filter = JSON.parse(sessionStorage.getItem("filter"));
    console.log("마커 저장 정보 :", props.markerInfo);
    markerInfos = `{"markers" : [${JSON.stringify(
      props.markerInfo
    )}], "title": "${title.value}"}`;
    // markerInfos.markers = props.markerInfo;
    // markerInfos.title = title.value;
    const response = await markerSave(JSON.parse(markerInfos));
    router.push("/custom/custom");
  } catch (error) {
    console.error(error);
  }
};
</script>

<template>
  <div>
    <v-btn
      class="text-white"
      icon="mdi-map-marker"
      size="x-large"
      color="#4DD0E1"
      title="마커 저장하기"
      @click="dialog = true"
    ></v-btn>
    <v-dialog width="auto" v-model="dialog">
      <v-card>
        <v-card-title class="text-cyan-lighten-3"> 마커 저장 </v-card-title>
        <v-card-item>
          <v-card-text
            >현재 위치 주소 : {{ props.markerInfo.address }}</v-card-text
          >
          <v-text-field
            label="마커 제목"
            variant="outlined"
            color="#4DD0E1"
            v-model="title"
          ></v-text-field>
        </v-card-item>
        <v-card-actions>
          <v-btn
            class="offset-3 btn"
            color="#4DD0E1"
            variant="outlined"
            @click="saveMarker"
            >저장</v-btn
          >
          <v-btn
            class="btn"
            color="#4DD0E1"
            variant="outlined"
            @click="dialog = false"
            >닫기</v-btn
          >
        </v-card-actions>
      </v-card>
    </v-dialog>
  </div>
</template>

<style scoped>
.v-text-field::v-deep {
  width: 380px;
}
.v-input::v-deep {
  padding-top: 20px;
}
.v-card-text::v-deep {
  padding: 5px;
}
.btn {
  width: 100px;
}
</style>
