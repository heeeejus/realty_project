<script setup>
import { computed, onMounted } from "vue";
import { userAuthStore } from "@/stores/auth";
import { RouterLink, useRouter } from "vue-router";

const authStore = userAuthStore();
const isLogin = computed(() => !!authStore.token); //!!의 경우 해당 정보가 truthy하다면 true를 반환
const nickname = computed(() => authStore.user.nickname);
const router = useRouter();

const homeIcon = "../src/assets/img/icon/IconHome.png";
const logOutIcon = "../src/assets/img/icon/IconLogOut.png";
const addUserIcon = "../src/assets/img/icon/IconAddUser.png";
const userIcon = "../src/assets/img/icon/IconUser.png";
const logInIcon = "../src/assets/img/icon/IconLogIn.png";
const updateIcon = "../src/assets/img/icon/IconUpdate.png";

const logout = () => {
  if (!confirm("로그아웃 하시겠습니까?")) return;
  authStore.logout();
  router.push("/");
};

onMounted(() => {
  //authStore.logout();
});
</script>

<template>
  <v-navigation-drawer permanent width="60">
    <v-list>
      <v-list-item title="ㅂㄷㅅ"></v-list-item>
    </v-list>
    <v-divider></v-divider>
    <v-list class="">
      <v-list-item link to="/"
        ><v-btn icon="mdi-home" class="btn"></v-btn
      ></v-list-item>
      <v-list-item v-show="!isLogin" link to="/login" title=""
        ><v-btn icon="mdi-login" class="btn"></v-btn
      ></v-list-item>
      <v-list-item v-show="!isLogin" link to="/signup" title=""
        ><v-btn icon="mdi-account-plus" class="btn"> </v-btn
      ></v-list-item>
      <v-list-item v-show="!isLogin" link to="/reissue-password" title=""
        ><v-btn icon="mdi-email-arrow-right-outline" class="btn"> </v-btn
      ></v-list-item>
      <v-list-item
        v-show="isLogin"
        :title="nickname"
        :class="{ vListItemTitle: isLogin }"
      ></v-list-item>
      <v-list-item v-show="isLogin" link @click="logout" title=""
        ><v-btn icon="mdi-logout" class="btn"> </v-btn
      ></v-list-item>
      <v-list-item v-show="isLogin" link to="/update" title=""
        ><v-btn icon="mdi-account-circle" class="btn"> </v-btn
      ></v-list-item>
    </v-list>
  </v-navigation-drawer>
</template>

<style scoped>
.v-list-item--density-default:not(
    .v-list-item--nav
  ).v-list-item--one-line::v-deep {
  padding: 5px;
}
.btn {
  width: 40px;
  background-color: transparent;
  box-shadow: none;
}
.btn:hover {
  box-shadow: none;
}
.btn:focus {
  box-shadow: none;
}
.v-list-item-title::v-deep {
  height: 70px;
}
.vListItemTitle{
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>
