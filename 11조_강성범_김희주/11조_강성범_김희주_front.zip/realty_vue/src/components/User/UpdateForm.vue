<script setup>
import { ref } from "vue";
import { userAuthStore } from "@/stores/auth";
import { updateUser, removeUser } from "@/api/user";
import { useRouter } from "vue-router";

const router = useRouter();

const authStore = userAuthStore();

const updateForm = ref({
  username: authStore.user.username,
  nickname: "",
  password: "",
});
//valid 유효성 검사 만들기
//emailRules: [
// v => !!v || 'E-mail is required',
//       v => /.+@.+/.test(v) || 'E-mail must be valid'
//     ]
const update = () => {
  console.log("회원 정보 수정 : ", updateForm.value);
  updateUser(
    updateForm.value,
    (response) => {
      console.log(response);
      authStore.updateNickname(updateForm.value.nickname)
      router.push("/");
    },
    (error) => {
      console.log(error);
    }
  );
};

const remove = () => {
  if (!confirm("탈퇴 하시겠습니까?")) return;
  
  removeUser(
    (response) => {
      console.log(response);
      authStore.logout();
      router.push("/");
    },
    (error) => {
      console.log(error);
    }
  );
};
</script>
<!-- <v-text-field
v-model="registForm.username"
:rules="nameRules"
:counter="10"
:error-messages="nameErrors"
label="First name"
required
></v-text-field> -->
<template>
  <v-sheet class="mx-auto"
    ><v-form v-model="valid">
      <v-flex xs12 md4>
        <v-text-field
          disabled
          v-model="updateForm.username"
          label="Email"
          required
        ></v-text-field>
      </v-flex>

      <v-flex xs12 md4>
        <v-text-field
          v-model="updateForm.nickname"
          label="nickname"
          required
        ></v-text-field>
      </v-flex>

      <v-flex xs12 md4>
        <v-text-field
          v-model="updateForm.password"
          label="password"
          type="password"
          required
        ></v-text-field>
      </v-flex>
      <v-container fluid>
        <v-row justify="center">
          <v-col cols="12" sm="6" md="4">
            <v-btn block rounded="xl" size="x-large" @click="update()"
              >수정</v-btn
            >
          </v-col>
          <v-col cols="12" sm="6" md="4">
            <v-btn block rounded="xl" size="x-large" @click="remove()"
              >탈퇴</v-btn
            >
          </v-col>
        </v-row>
      </v-container>

      <!-- <div class="d-flex flex-column">
        <v-btn rounded="xl" size="x-large" class="mt-1" @click="regist"
          >Submit</v-btn
        >
        <v-btn rounded="xl" size="x-large" class="mt-2" @click="clear"
          >Clear</v-btn
        >
      </div> -->
    </v-form>
  </v-sheet>
</template>

<style scoped></style>
