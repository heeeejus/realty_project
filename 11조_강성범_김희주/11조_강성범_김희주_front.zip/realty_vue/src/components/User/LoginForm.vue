<script setup>
import { ref } from "vue";
import { userAuthStore } from "../../stores/auth";
import { useRouter } from "vue-router";

const authStore = userAuthStore();

const router = useRouter();

const loginForm = ref({
  username: "",
  password: "",
});

const login = async () => {
  try {
    await authStore.login(loginForm.value);
    router.push("/");
  } catch (error) {
    alert("잘못된 정보입니다.")
    console.log("로그인 실패 : ", error);
    loginForm.value.username = "";
    loginForm.value.password = "";
    router.push("/login");
  }
};
</script>

<template>
  <v-sheet class="mx-auto">
    <v-form v-model="valid" class="mt-8" @submit.prevent="login">
      <v-flex xs12 md4>
        <v-text-field
          v-model="loginForm.username"
          label="Email"
          required
        ></v-text-field>
      </v-flex>
      <v-flex xs12 md4>
        <v-text-field
          v-model="loginForm.password"
          label="password"
          type="password"
          required
        ></v-text-field>
      </v-flex>
      <v-container>
        <v-row justify="center">
          <v-col cols="12" sm="6" md="4">
            <v-btn block rounded="xl" size="x-large" type="submit">로그인</v-btn>
          </v-col>
        </v-row>
      </v-container>
    </v-form>
  </v-sheet>
</template>

<style scoped></style>
