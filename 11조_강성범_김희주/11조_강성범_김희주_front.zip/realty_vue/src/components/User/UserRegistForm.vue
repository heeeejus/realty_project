<script setup>
import { ref } from "vue";
import { registUser } from "@/api/user";
import { useRouter } from "vue-router";

const router = useRouter();

const registForm = ref({
  username: "",
  nickname: "",
  password: "",
});
//valid 유효성 검사 만들기
//emailRules: [
// v => !!v || 'E-mail is required',
//       v => /.+@.+/.test(v) || 'E-mail must be valid'
//     ]
const regist = () => {
  console.log("회원 등록 : ", registForm.value);
  registUser(
    registForm.value,
    (response) => {
      console.log(response);
      router.push("/login");
    },
    (error) => {
      alert("회원가입 실패!");
      console.log(error);
    }
  );
};
const clear = () => {
  registForm.value.username = "";
  registForm.value.nickname = "";
  registForm.value.password = "";
};
</script>
<!-- <v-text-field
v-model="registForm.username"
:rules="nameRules"
:counter="10"
:error-messages="nameErrors"
label="First name"
required
></v-text-field> -->
<template>
  <v-sheet class="mx-auto"
    ><v-form v-model="valid">
      <v-flex xs12 md4>
        <v-text-field
          hint="현재 사용하고 있는 이메일을 입력해 주세요"
          v-model="registForm.username"
          label="Email"
          required
        ></v-text-field>
      </v-flex>

      <v-flex xs12 md4>
        <v-text-field
          v-model="registForm.nickname"
          label="nickname"
          required
        ></v-text-field>
      </v-flex>

      <v-flex xs12 md4>
        <v-text-field
          v-model="registForm.password"
          label="password"
          type="password"
          required
        ></v-text-field>
      </v-flex>
      <v-container fluid>
        <v-row justify="center">
          <v-col cols="12" sm="6" md="4">
            <v-btn block rounded="xl" size="x-large" @click="regist"
              >Submit</v-btn
            >
          </v-col>
          <v-col cols="12" sm="6" md="4">
            <v-btn block rounded="xl" size="x-large" @click="clear"
              >Clear</v-btn
            >
          </v-col>
        </v-row>
      </v-container>

      <!-- <div class="d-flex flex-column">
        <v-btn rounded="xl" size="x-large" class="mt-1" @click="regist"
          >Submit</v-btn
        >
        <v-btn rounded="xl" size="x-large" class="mt-2" @click="clear"
          >Clear</v-btn
        >
      </div> -->
    </v-form>
  </v-sheet>
</template>

<style scoped></style>
