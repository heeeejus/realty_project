<script setup>
import { ref } from "vue";
import { reIssuePassword } from "@/api/user";
import { useRouter } from "vue-router";

const router = useRouter();

const reIssueForm = ref({
  username: "",
});

const reIssue = async () => {
  console.log("비밀번호 재발급");
  reIssuePassword(
    reIssueForm.value,
    (response) => {
      alert("메일로 임시 비밀번호가 발급 되었습니다.")
      console.log(response);
      router.push("/login");
    },
    (error) => {
      alert("비밀번호 재발급 실패!");
      console.log(error);
    }
  );
};
</script>

<template>
  <v-sheet class="mx-auto">
    <v-form v-model="valid" class="mt-8" @submit.prevent="login">
      <v-flex xs12 md4>
        <v-text-field
          v-model="reIssueForm.username"
          label="Email"
          required
        ></v-text-field>
      </v-flex>
      <v-container>
        <v-row justify="center">
          <v-col cols="12" sm="6" md="8">
            <v-btn block rounded="xl" size="x-large" type="submit" @click="reIssue()">임시 비밀번호 발급</v-btn>
          </v-col>
        </v-row>
      </v-container>
    </v-form>
  </v-sheet>
</template>

<style scoped></style>
