<script setup>
import VKakaoMapDetail from "../common/VKakaoMapDetail.vue";
import VListNav from "../common/VListNav.vue";
import VChipPanel from "../common/VChipPanel.vue";
import VMarkerShareBtn from "../common/VMarkerShareBtn.vue";
import VCustomLikeBtn from "../common/VCustomLikeBtn.vue";
import { useMarkerStore } from "../../stores/markers";

import { ref, onMounted, onBeforeMount } from "vue";
import { markerInfoRequest } from "@/api/custom.js";
import { useRoute } from "vue-router";

const route = useRoute();
const customId = route.params.customid;
const markerStore = useMarkerStore();

// 글의 '마커' 정보가 저장된다.
const chipHeight = ref();
const chipWidth = ref();
const markerInfo = ref(sessionStorage.getItem("markerInfo"));
const position = ref([]);
const chipName = ["면적", "거래일", "거래가격", "도보/자전거"];

const vkakaoMapDetailRef = ref(null);

// 마커 정보에 따른 각 집 요약 정보가 저장된다.
//const houseSummaryInfoOfMarkers = ref([]);

const makerInfoRequest = () => {
  console.log("서버에 marker 정보 요청", customId);
  markerInfoRequest(
    customId,
    ({ data }) => {
      markerInfo.value = data.data[0];

      console.log("서버에서 가져온 정보");
      console.log(markerInfo.value);
      sessionStorage.setItem("markerInfo", JSON.stringify(markerInfo.value));
      sessionStorage.setItem("filter", JSON.stringify(markerInfo.value.filter));
    },
    (error) => {
      console.log(error);
    }
  );
};

const cardShow = (cardShow) => {
  chipHeight.value = !cardShow;
  chipWidth.value = cardShow;
};

const markerInfoEvent = (marker) => {
  //마커에 대한 정보를 넘겨서 VListNav에서 리스트 보여주기
  console.log("marker ", marker);
  markerInfo.value = marker;
  console.log("session filter", JSON.parse(sessionStorage.getItem("filter")));
  sessionStorage.setItem("filter", JSON.stringify(markerInfo.value.filter));
  sessionStorage.setItem("markerInfo", JSON.stringify(markerInfo.value));
};

const infoListEvent = (infoList) => {
  //infoList의 latlng position에 저장
  sessionStorage.setItem("position", "");
  position.value = [];
  infoList.forEach((val) => {
    const tmp = {
      title: val.apartmentName,
      lat: val.lat,
      lng: val.lng,
      //latlng: new kakao.maps.LatLng(val.lat, val.lng),
    };
    //markerStore.sessionPositionUpdate(markerStore.position);
    position.value.push(tmp);
  });
  const obj = { data: position.value };
  sessionStorage.setItem("position", JSON.stringify(obj));
};

// const houseSummaryInfoOfMarkersRequest = () => {
//   // 각 마커마다 집 거래 요약 정보 추가

//   for (let i = 0; i < markerInfo.value.length; i++) {
//     console.log(i, "번 째 마커 정보 요청");

//     markerList(markerInfo.value[i]); // 서버에 요청 보내는 부분 /api/realty.js
//   }
// };

onBeforeMount(() => {
  makerInfoRequest();
});
</script>

<template>
  <v-container fluid class="pd-0">
    <v-container fluid class="d-flex v-con">
      <VListNav
        class="list-nav"
        v-on:infoList="infoListEvent"
        :markerInfo="markerInfo"
      ></VListNav>
      <VKakaoMapDetail
        ref="vkakaoMapDetailRef"
        class="map"
        :markerInfo="markerInfo"
        :position="position"
      ></VKakaoMapDetail>
      <div class="d-flex chip-panel" :class="{ 'chip-panel-width': chipWidth }">
        <VChipPanel
          :disable="true"
          :markerInfo="markerInfo"
          :class="{
            'chip-panel-height': chipHeight,
          }"
          v-on:card-show="cardShow"
          v-for="name in chipName"
          :key="chipName"
          :chip-name="name"
        ></VChipPanel>
      </div>
      <!-- <VSearchBar class="search-bar"></VSearchBar> -->
      <VMarkerShareBtn
        class="marker-save-btn"
        :markerInfo="markerInfo"
        @click="markerInfoEvent(markerInfo)"
      ></VMarkerShareBtn>
      <VCustomLikeBtn
        class="marker-like-btn"
        :customId="customId"
      ></VCustomLikeBtn>
    </v-container>
  </v-container>
</template>

<style scoped>
.v-container::v-deep {
  height: 100%;
}
.pd-0 {
  padding: 0;
}
.v-con {
  padding: 0;
  position: relative;
}
.map {
  z-index: auto;
}
.list-nav {
  position: absolute;
  top: 8%;
  left: 1%;
  bottom: 2%;
  height: 90%;
  z-index: 3;
}
.chip-panel {
  position: absolute;
  top: 1%;
  left: 1%;
  bottom: 92%;
  width: 18%;
  z-index: 4;
}
.chip-panel-height {
  height: 5%;
  /* z-index: -1 !important; */
}
.chip-panel-width {
  width: 60%;
  /* z-index: -1 !important; */
}
.search-bar {
  position: absolute;
  top: 1%;
  right: 1%;
  width: 25%;
  z-index: 4;
}
.marker-save-btn {
  position: absolute;
  bottom: 2%;
  right: 2%;
  z-index: 4;
}
.marker-like-btn {
  position: absolute;
  bottom: 2%;
  right: 8%;
  z-index: 4;
}
</style>
