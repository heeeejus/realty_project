<script setup>
import { useRouter } from "vue-router";
const props = defineProps({ custom: Object });

const router = useRouter();

const moveDetail = () => {
  console.log("실행");
  router.push({ name: "custom-detail", params: { customid: props.custom.id } });
};
</script>

<template>
  <tr class="text-center" @click="moveDetail()">
    <th scope="row">{{ custom.id }}</th>
    <td class="text-start">{{ custom.title }}</td>
    <td>{{ custom.author }}</td>
    <td>{{ custom.look }}</td>
    <td>{{ custom.createDate }}</td>
  </tr>
</template>

<style scoped>
a {
  text-decoration: none;
}

td {
  padding: 15px;
}
</style>
