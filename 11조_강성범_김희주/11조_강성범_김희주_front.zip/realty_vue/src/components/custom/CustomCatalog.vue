<script setup>
import { ref, onMounted } from "vue";
import {
  customCatalogs,
  myCatalogRequest,
  myStarRequest,
} from "@/api/custom.js";

import PageNavigation from "@/components/common/PageNavigation.vue";
import CustomCatalogItem from "./item/CustomCatalogItem.vue";

const isLogin = localStorage.getItem("token") == (null || "") ? false : true;

const selectOption = ref([
  { text: "all", value: "all" },
  { text: "title", value: "title" },
  { text: "author", value: "userId" },
]);

const customs = ref([]);
const currentPage = ref(1);
const totalPage = ref(0);
const { VITE_CUSTOM_CATALOG_SIZE } = import.meta.env;

const param = ref({
  page: currentPage.value,
  size: VITE_CUSTOM_CATALOG_SIZE,
  type: "",
  value: "",
});

onMounted(() => {
  getCustomCatalog();
});

const getCustomCatalog = () => {
  console.log("서버에 cusom catalog 요청", param.value);
  customCatalogs(
    param.value,
    ({ data }) => {
      customs.value = data.data;
      currentPage.value = data.currentPage;
      totalPage.value = data.totalPage;

      console.log(customs.value);
    },
    (error) => {
      console.log(error);
    }
  );
};

const onPageChange = (val) => {
  console.log(val + "번 페이지로 이동 준비 끝!!!");
  currentPage.value = val;
  param.value.page = val;
  getCustomCatalog();
};

const myStar = () => {
  // 좋아요 글 -> 헤더에 토큰 담아서 요청
  console.log("서버에 사용자의 좋아요 글 요청", param.value);
  param.value.page = 1;
  myStarRequest(
    param.value,
    ({ data }) => {
      customs.value = data.data;
      currentPage.value = data.currentPage;
      totalPage.value = data.totalPage;

      console.log(customs.value);
    },
    (error) => {
      console.log(error);
    }
  );
};

const myCatalog = () => {
  // 내가 작성한 글

  console.log("사용자가 작성한 글", param.value);
  param.value.page = 1;
  myCatalogRequest(
    param.value,
    ({ data }) => {
      customs.value = data.data;
      currentPage.value = data.currentPage;
      totalPage.value = data.totalPage;

      console.log(customs.value);
    },
    (error) => {
      console.log(error);
    }
  );
};
</script>

<template>
  <div class="custom-page-header">
    <p>다른 사람들이 만든 매물 정보를 확인해 보세요!</p>
  </div>
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-10"></div>
      <div class="col-lg-10">
        <div class="condition-wrap">
          <div class="only-own">
            <v-show></v-show>
            <v-btn
              v-show="isLogin"
              fab
              dark
              class="my-star-btn"
              @click="myStar()"
            >
              나의 좋아요 글
            </v-btn>
            <v-btn
              v-show="isLogin"
              fab
              dark
              class="only-own-btn"
              @click="myCatalog()"
              >내가 작성한 글
            </v-btn>
          </div>
          <div class="custom-search-wrap">
            <form class="d-flex custom-search-form">
              <v-select
                v-model="param.type"
                class="custom-search-select"
                :items="selectOption.map((option) => option.text)"
                label="검색조건"
                item-value="value"
                variant="solo"
              ></v-select>

              <v-text-field
                v-model="param.value"
                class="custom-search-text"
                type="input"
                label=""
                variant="solo"
                hint="어떤 글을 찾고 있어요?"
              ></v-text-field>
              <v-btn
                fab
                dark
                class="custom-search-btn"
                @click="getCustomCatalog"
              >
                <v-icon dark>mdi-magnify</v-icon>
              </v-btn>
            </form>
          </div>
        </div>
        <table class="table table-hover">
          <thead>
            <tr class="text-center">
              <th scope="col">글번호</th>
              <th scope="col">제목</th>
              <th scope="col">작성자</th>
              <th scope="col">조회수</th>
              <th scope="col">작성일</th>
            </tr>
          </thead>
          <tbody>
            <CustomCatalogItem
              v-for="custom in customs"
              :key="custom.id"
              :custom="custom"
            ></CustomCatalogItem>
          </tbody>
        </table>
      </div>
      <PageNavigation
        :current-page="currentPage"
        :total-page="totalPage"
        @pageChange="onPageChange"
      ></PageNavigation>
    </div>
  </div>
</template>

<style scoped>
.custom-page-header {
  text-align: center;
}

.custom-page-header > p {
  background: linear-gradient(to right, #6cbbff, #91b6eb);
  -webkit-background-clip: text; /* 텍스트에만 그라데이션 적용 */
  -webkit-text-fill-color: transparent; /* 텍스트 색상을 투명하게 설정하여 그라데이션이 보이도록 함 */
  font-weight: bold;
  font-size: 2.5vw;
  margin: 20px 0;
}
.table {
  width: 100%;
  height: 100%;
  margin: 10px 0 5px 5px;

  border-collapse: separate;
  border-spacing: 10px 10px;
}

.table th {
  background: linear-gradient(to right, #2d81ff, #6cbbff);
  font-weight: bold;
  font-size: 1.5em;
  color: #fdfdfd;
}

.table th {
  padding: 15px;
}

.table tbody tr:nth-child(even) {
  background: linear-gradient(to left, #6cbbff 0%, #91b6eb 50%, #6cbbff 100%);
  color: #fdfdfd;
}

.table tbody tr {
  font-size: 1.1em;
  transition: font-size 1s ease;
}

.table tbody tr:hover {
  cursor: pointer;
}

.table .remove-btn {
  background: red;
}

.condition-wrap {
  display: flex;
  flex-direction: row;
}

.only-own {
  display: flex;
  flex-direction: row;
}

.only-own-btn {
  color: #fdfdfd;
  font-weight: bold;
  background: linear-gradient(to left, #6cbbff 0%, #91b6eb 50%, #6cbbff 100%);
  height: 56px;
  margin-left: 10px;
}

.my-star-btn {
  color: #91b6eb;
  font-weight: bold;
  background: #fdfdfd;
  margin-left: 10px;

  height: 56px;
}

.custom-search-wrap {
  width: 100%;
  display: flex;
  justify-content: flex-end;
}

.custom-search-form {
  margin-bottom: 30px;
}

.custom-search-select {
  height: 56px;
  width: 160px;
  margin-right: 10px;
  margin-left: 10px;
}

.custom-search-text {
  height: 56px;
  width: 25vw;
  margin-right: 10px;
}

.custom-search-btn {
  height: 56px;
  width: 70px;
  margin-right: 10px;
}
</style>
